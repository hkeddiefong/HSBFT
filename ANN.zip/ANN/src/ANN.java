import org.deeplearning4j.nn.conf.ComputationGraphConfiguration;
import org.deeplearning4j.nn.conf.MultiLayerConfiguration;
import org.deeplearning4j.nn.conf.NeuralNetConfiguration;
import org.deeplearning4j.nn.conf.Updater;
import org.deeplearning4j.nn.weights.WeightInit;

public class ANN {
	public static void main(String[] args)
	{
		ComputationGraphConfiguration configuration = new NeuralNetConfiguration.Builder()
			   	.weightInit(WeightInit.XAVIER)
				.learningRate(0.5)
				.updater(Updater.RMSPROP)
				.optimizationAlgo(OptimizationAlgorithm.STOCHASTIC_GRADIENT_DESCENT).iterations(nIterations)
				.seed(seed)
				.graphBuilder()
				.addInputs("additionIn", "sumOut")
				.setInputTypes(InputType.recurrent(FEATURE_VEC_SIZE), InputType.recurrent(FEATURE_VEC_SIZE))
				.addLayer("encoder", new GravesLSTM.Builder().nIn(FEATURE_VEC_SIZE).nOut(numHiddenNodes).activation("softsign").build(),"additionIn")
				.addVertex("lastTimeStep", new LastTimeStepVertex("additionIn"), "encoder")
				.addVertex("duplicateTimeStep", new DuplicateToTimeSeriesVertex("sumOut"), "lastTimeStep")
				.addLayer("decoder", new GravesLSTM.Builder().nIn(FEATURE_VEC_SIZE+numHiddenNodes).nOut(numHiddenNodes).activation("softsign").build(), "sumOut","duplicateTimeStep")
				.addLayer("output", new RnnOutputLayer.Builder().nIn(numHiddenNodes).nOut(FEATURE_VEC_SIZE).activation("softmax").lossFunction(LossFunctions.LossFunction.MCXENT).build(), "decoder")
				.setOutputs("output")
				.pretrain(false).backprop(true)
				.build();
		
		
		MultiLayerConfiguration conf = new NeuralNetConfiguration.Builder()
				.seed(seed)
			    .iterations(iterations)
				 .activation("tanh")
				 .weightInit(WeightInit.XAVIER)
				 .learningRate(0.1)
				 .regularization(true).l2(1e-4)
				 .list()
				 .layer(0, new DenseLayer.Builder().nIn(numInputs).nOut(3)
				     .build())
				 .layer(1, new DenseLayer.Builder().nIn(3).nOut(3)
				     .build())
				 .layer(2, new OutputLayer.Builder(LossFunctions.LossFunction.NEGATIVELOGLIKELIHOOD)
				     .activation("softmax")
				     .nIn(3).nOut(outputNum).build())
				 .backprop(true).pretrain(false)
				 .build();
		
	}

}
